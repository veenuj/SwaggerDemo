package com.restaurant.nearByRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NearByRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
